package testing.control;

import static org.junit.Assert.*;

import java.io.IOException;

import javax.servlet.ServletException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import it.unisa.control.AjaxProductSelectedController;
import it.unisa.control.AwardsController;

public class TC_AwardsController {
	private AwardsController servlet;
	private MockHttpServletRequest request;
	private MockHttpServletResponse response;

	@Before
	public void setUp() throws Exception {
		servlet = new AwardsController();
		request = new MockHttpServletRequest();
		response = new MockHttpServletResponse();  
	}

	@After
	public void tearDown() throws Exception {
		servlet = null; 
		request = null;
		response = null;
	}

	@Test
	public void testController_details() throws ServletException, IOException {
		request.addParameter("action", "details");
		request.addParameter("name", "Cestelli");

		servlet.doGet(request, response);
	}

	@Test
	public void testController_getPicture() throws ServletException, IOException {
		request.addParameter("action", "getPicture");
		request.addParameter("name", "Cestelli");

		servlet.doGet(request, response);
	} 

	@Test
	public void testController_delete() throws ServletException, IOException {
		request.addParameter("action", "delete");
		request.addParameter("name", "Caffettiera");

		servlet.doGet(request, response);
	}

	@Test
	public void testController_insert() throws ServletException, IOException {
		request.addParameter("action", "insert");
		request.addParameter("nameAward", "Caffettiera");
		request.addParameter("descriptionAward", "prova descrizione");
		request.addParameter("pointsAward", "350");
		request.addParameter("quantityAward", "30");

		servlet.doGet(request, response);
	}

	@Test
	public void testController_updateAward() throws ServletException, IOException {
		request.addParameter("action", "updateAward");
		request.addParameter("idNameAward", "Caffettiera");
		
		request.addParameter("updateNameAward", "Caffettiera aggiornataa");
		request.addParameter("updateDescriptionAward", "prova descrizione");
		request.addParameter("updatePointsAward", "350");
		request.addParameter("updateQuantityAward", "30");

		servlet.doGet(request, response);
	}
}
