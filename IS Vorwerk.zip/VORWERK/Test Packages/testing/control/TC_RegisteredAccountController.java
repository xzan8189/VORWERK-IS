package testing.control;

import static org.junit.Assert.*;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import it.unisa.control.ProfiloController;
import it.unisa.control.RegisteredAccountController;

public class TC_RegisteredAccountController {
	private RegisteredAccountController servlet;
	private MockHttpServletRequest request;
	private MockHttpServletResponse response; 
	private HttpSession session;

	@Before
	public void setUp() throws Exception {
		servlet = new RegisteredAccountController();
		request = new MockHttpServletRequest();
		response = new MockHttpServletResponse();  
		session= request.getSession();
	}

	@After
	public void tearDown() throws Exception {
		servlet = null; 
		request = null;
		response = null;
		session= null;
	}

	//Non puoi ricevere il premio perch� non hai ancora comprato nulla dal carrello
	@Test
	public void testController_buyAward1() throws ServletException, IOException {
		request.addParameter("action", "buyAward");
		session.setAttribute("user", "we@gmail.com");
		request.addParameter("codeAward", "Cestelli");

		servlet.doGet(request, response);
	}
	
	@Test
	public void testController_addCarrelloRobot() throws ServletException, IOException {
		request.addParameter("action", "addCarrelloRobot");
		session.setAttribute("user", "we@gmail.com");
		request.addParameter("codeRobot", "1");

		servlet.doGet(request, response);
	}

	//Riaggiungo lo stesso prodotto per aggiornare la quantit� che ho nel carrello
	@Test
	public void testController_addCarrelloRobot1() throws ServletException, IOException {
		request.addParameter("action", "addCarrelloRobot");
		session.setAttribute("user", "we@gmail.com");
		request.addParameter("codeRobot", "1");

		servlet.doGet(request, response);
	}
	
	//La quantit� del robot 0 quindi � esaurito il robot con code 1
	@Test
	public void testController_addCarrelloRobo2() throws ServletException, IOException {
		request.addParameter("action", "addCarrelloRobot");
		session.setAttribute("user", "we@gmail.com");
		request.addParameter("codeRobot", "1");

		servlet.doGet(request, response);
	}
	

	//Stai comprando tutto quello che c'� nel carrello
	@Test
	public void testController_buyAll() throws ServletException, IOException {
		request.addParameter("action", "buyAll");
		session.setAttribute("user", "we@gmail.com");
		request.addParameter("codeAward", "Cestelli");

		servlet.doGet(request, response);
	}

	//Adesso puoi ricevere il premio perch� hai abbastanza punti
	@Test
	public void testController_buyAward2() throws ServletException, IOException {
		request.addParameter("action", "buyAward");
		session.setAttribute("user", "we@gmail.com");
		request.addParameter("codeAward", "Cestelli");

		servlet.doGet(request, response);
	}
	
	//Stai eliminando un robot dal carrello
	@Test
	public void testController_delete() throws ServletException, IOException {
		request.addParameter("action", "delete");
		session.setAttribute("user", "we@gmail.com");
		request.addParameter("code", "1");

		servlet.doGet(request, response);
	}

	//Hai pulito tutto quello che c'� nel carrello
	@Test
	public void testController_clear() throws ServletException, IOException {
		request.addParameter("action", "clear");
		session.setAttribute("user", "we@gmail.com");

		servlet.doGet(request, response);
	}
}
