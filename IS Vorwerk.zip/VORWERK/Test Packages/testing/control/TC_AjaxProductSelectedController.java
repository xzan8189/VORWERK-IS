package testing.control;

import static org.junit.Assert.*;

import java.io.IOException;

import javax.servlet.ServletException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import it.unisa.control.AjaxProductSelectedController;
import it.unisa.control.Controller;

public class TC_AjaxProductSelectedController {
	private AjaxProductSelectedController servlet;
	private MockHttpServletRequest request;
	private MockHttpServletResponse response;

	@Before
	public void setUp() throws Exception {
		servlet = new AjaxProductSelectedController();
		request = new MockHttpServletRequest();
		response = new MockHttpServletResponse();  
	}

	@After
	public void tearDown() throws Exception {
		servlet = null; 
		request = null;
		response = null;
	}

	@Test
	public void testController_details_clickSuggerimento() throws ServletException, IOException {
		request.addParameter("action", "details");
		request.addParameter("codeRobot", "1");

		servlet.doGet(request, response);
	}

	@Test
	public void testController_details_clickSearchButton() throws ServletException, IOException {
		request.addParameter("action", "details");
		request.addParameter("SearchRobot", "t");

		servlet.doGet(request, response);
	}
}
