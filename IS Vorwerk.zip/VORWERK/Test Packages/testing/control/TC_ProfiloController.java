package testing.control;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import it.unisa.control.ProfiloController;

public class TC_ProfiloController {
	private ProfiloController servlet;
	private MockHttpServletRequest request;
	private MockHttpServletResponse response; 
	private HttpSession session;

	@Before
	public void setUp() throws Exception {
		servlet = new ProfiloController();
		request = new MockHttpServletRequest();
		response = new MockHttpServletResponse();  
		session= request.getSession();
	}

	@After
	public void tearDown() throws Exception {
		servlet = null; 
		request = null;
		response = null;
		session=null;
	}

	@Test
	public void testController_takeListOrdini() throws ServletException, IOException {
		request.addParameter("action", "takeListOrdini");
		session.setAttribute("user", "we@gmail.com");

		servlet.doGet(request, response);
	}

}
