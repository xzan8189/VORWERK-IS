package testing.control;

import static org.junit.Assert.*;

import java.io.IOException;

import javax.servlet.ServletException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import it.unisa.control.AjaxController;
import it.unisa.control.Controller;

public class TC_AjaxController {
	private AjaxController servlet;
	private MockHttpServletRequest request;
	private MockHttpServletResponse response;

	@Before
	public void setUp() throws Exception {
		servlet = new AjaxController();
		request = new MockHttpServletRequest();
		response = new MockHttpServletResponse(); 
	}

	@After
	public void tearDown() throws Exception {
		servlet = null; 
		request = null;
		response = null;
	}

	@Test
	public void testController_nameRobot() throws ServletException, IOException {
		request.addParameter("nameRobot", "t");

		servlet.doGet(request, response);
	}

}
