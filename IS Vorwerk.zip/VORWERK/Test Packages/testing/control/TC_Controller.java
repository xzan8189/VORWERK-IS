package testing.control;

import static org.junit.Assert.*;

import java.io.IOException;

import javax.servlet.ServletException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import it.unisa.control.Controller;

public class TC_Controller {
	private Controller servlet;
	private MockHttpServletRequest request;
	private MockHttpServletResponse response;

	@Before
	public void setUp() throws Exception {
		servlet = new Controller();
		request = new MockHttpServletRequest();
		response = new MockHttpServletResponse(); 
	}

	@After
	public void tearDown() throws Exception {
		servlet = null;
		request = null;
		response = null;
	}

	@Test
	public void testController_details() throws ServletException, IOException {
		request.addParameter("action", "details");
		request.addParameter("code", "1");

		servlet.doGet(request, response);
	}

	@Test
	public void testController_getPicture() throws ServletException, IOException {
		request.addParameter("action", "getPicture");
		request.addParameter("code", "2");

		servlet.doGet(request, response);
	}
	
	@Test
	public void testController_delete() throws ServletException, IOException {
		request.addParameter("action", "delete");
		request.addParameter("code", "1");

		servlet.doGet(request, response);
	}

	@Test
	public void testController_insert() throws ServletException, IOException {
		request.addParameter("action", "insert");
		
		request.addParameter("name", "provaaaa");
		request.addParameter("description", "provaaaaa");
		request.addParameter("price", "12");
		request.addParameter("quantity", "12");

		servlet.doGet(request, response);
	}

	@Test
	public void testController_update() throws ServletException, IOException {
		request.addParameter("action", "updateRobot");
		
		request.addParameter("codeRobot", "2");
		request.addParameter("updateNameRobot", "nomeAggiornato");
		request.addParameter("updateDescriptionRobot", "descrizione aggiornata");
		request.addParameter("updatePriceRobot", "30");
		request.addParameter("updateQuantityRobot", "30");

		servlet.doGet(request, response);
	}
}
