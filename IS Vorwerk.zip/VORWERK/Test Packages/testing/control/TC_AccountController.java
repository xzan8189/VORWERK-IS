package testing.control;

import java.io.IOException;

import javax.servlet.ServletException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.http.MediaType;
import it.unisa.control.AccountController;

public class TC_AccountController {
	private AccountController servlet;
	private MockHttpServletRequest request;
	private MockHttpServletResponse response;

	@Before
	public void setUp() throws Exception {
		servlet = new AccountController();
		request = new MockHttpServletRequest();
		response = new MockHttpServletResponse(); 
	}

	@After
	public void tearDown() throws Exception {
		servlet = null;
		request = null;
		response = null;
	}

	@Test
	public void testController_lastRobot() throws ServletException, IOException {
		request.addParameter("action", "lastRobot"); 

		servlet.doGet(request, response);
	}

	@Test
	public void testController_getPictureRobot() throws ServletException, IOException {
		request.addParameter("action", "getPictureRobot");
		request.addParameter("code", "1");

		servlet.doGet(request, response);
	}

	@Test
	public void testController_getPictureAward() throws ServletException, IOException {
		request.addParameter("action", "getPictureAward");
		request.addParameter("name", "Cestelli");

		servlet.doGet(request, response);
	}
}
