package it.unisa.model;

import java.sql.Date;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PremioInOrdine {
	//variabili d'istanza
	private int codeOrdine;
	private String idPremio;
	private String emailCliente;
	private Date data_richiesta;
	private int punti;
	private int quantit�_scelta;
	
	//metodi costruttori
	public PremioInOrdine() {
		/*vuoto*/
	}

	public PremioInOrdine(int codeOrdine, String idPremio, String emailCliente, Date data_richiesta, int punti,
			int quantit�_scelta) {
		this.codeOrdine = codeOrdine;
		this.idPremio = idPremio;
		this.emailCliente = emailCliente;
		this.data_richiesta = data_richiesta;
		this.punti = punti;
		this.quantit�_scelta = quantit�_scelta;
	}

	//metodi d'accesso
	public int getCodeOrdine() {
		return codeOrdine;
	}
	
	public String getIdPremio() {
		return idPremio;
	}

	public String getEmailCliente() {
		return emailCliente;
	}

	public Date getData_richiesta() {
		return data_richiesta;
	}

	public int getQuantit�_scelta() {
		return quantit�_scelta;
	}

	public int getPunti() {
		return punti;
	}

	//metodi modificatori
	public void setCodeOrdine(int codeOrdine) {
		this.codeOrdine = codeOrdine;
	}
	
	public void setIdPremio(String idPremio) {
		this.idPremio = idPremio;
	}

	public void setEmailCliente(String emailCliente) {
		this.emailCliente = emailCliente;
	}

	public void setData_richiesta(Date data_richiesta) {
		this.data_richiesta = data_richiesta;
	}

	public void setQuantit�_scelta(int quantit�_scelta) {
		this.quantit�_scelta = quantit�_scelta;
	}

	public void setPunti(int punti) {
		this.punti = punti;
	}
	// metodi di validazione dei campi
	public boolean validateIdPremio(String idPremio) {
		String regex = "[A-Z a-z 0-9 ^\\n]{5, 30}";
		Pattern pt = Pattern.compile(regex);
		Matcher mt = pt.matcher(idPremio);
		boolean res = mt.matches();
		if (res)
			System.out.println("S�, matcha! idPremio: " + idPremio);
		else
			System.out.println("Non matcha, idPremio: " + idPremio);

		return res;
	}
	
	public boolean validateEmailCliente(String emailCliente) {
		String regex = "[A-z 0-9\\.\\+_-]+@[A-z 0-9\\._-]+\\.[A-z]{2,3}";
		Pattern pt = Pattern.compile(regex);
		Matcher mt = pt.matcher(emailCliente);
		boolean res = mt.matches();
		if (res)
			System.out.println("S�, matcha! emailCliente: " + emailCliente);
		else
			System.out.println("Non matcha, emailCliente: " + emailCliente);

		return res;
	}

	public boolean validateData_richiesta(String data_richiesta) {
		String regex = "([12]\\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01]))";
		Pattern pt = Pattern.compile(regex);
		Matcher mt = pt.matcher(data_richiesta);
		boolean res = mt.matches();
		if (res)
			System.out.println("S�, matcha! data_richiesta: " + data_richiesta + "\n");
		else
			System.out.println("Non matcha, data_richiesta: " + data_richiesta + "\n");

		return res;
	}
	
	public boolean validateQuantit�Scelta(String quantit�_scelta) {
		String regex = "[0-9]{1,3}";
		Pattern pt = Pattern.compile(regex);
		Matcher mt = pt.matcher(quantit�_scelta);
		boolean res = mt.matches();
		if (res)
			System.out.println("S�, matcha! quantit� scelta: " + quantit�_scelta + "\n");
		else
			System.out.println("Non matcha, quantit� scelta: " + quantit�_scelta + "\n");

		return res;
	}

	public String validatePremioInOrdine() {
		String res = "";
		System.out.println();

		if (idPremio!=null && !validateIdPremio(idPremio)) /*validate idPremio*/
			res += "L'idPremio: <b>" + idPremio + "</b> non � valido<br>";
		
		if (emailCliente!=null && !validateEmailCliente(emailCliente)) /*validate emailCliente*/
			res += "L'emailCliente: <b>" + emailCliente + "</b> non � valida<br>";
		
		if (data_richiesta!=null && !validateData_richiesta(data_richiesta.toString())) /*validate data_richiesta*/
			res += "La data di richiesta: <b>" + data_richiesta + "</b> non � valida<br>";

		if (String.valueOf(quantit�_scelta)!=null && !validateQuantit�Scelta(String.valueOf(quantit�_scelta))) /*validate quantit�_scelta*/
			res += "La quantit� scelta: <b>" + quantit�_scelta + "</b> non � valida<br>";
		return res;
	}
	
	//metodi sovrascritti
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof PremioInOrdine))
			return false;
		PremioInOrdine other = (PremioInOrdine) obj;
		return codeOrdine == other.codeOrdine && Objects.equals(data_richiesta, other.data_richiesta)
				&& Objects.equals(emailCliente, other.emailCliente) && Objects.equals(idPremio, other.idPremio)
				&& punti == other.punti && quantit�_scelta == other.quantit�_scelta;
	}

	@Override
	public String toString() {
		return "PremioInOrdine [codeOrdine=" + codeOrdine + ", idPremio=" + idPremio + ", emailCliente=" + emailCliente
				+ ", data_richiesta=" + data_richiesta + ", punti=" + punti + ", quantit�_scelta=" + quantit�_scelta
				+ "]";
	}
	
	
	
	
	

	
	
	
	
	
	
	
	
	
	
}//fine classe











