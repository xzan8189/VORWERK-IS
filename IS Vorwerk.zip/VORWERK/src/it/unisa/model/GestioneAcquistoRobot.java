package it.unisa.model;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import it.unisa.DriverManagerConnectionPool;
import it.unisa.control.RegisteredAccountController;

public class GestioneAcquistoRobot {
	// variabili d'istanza
	private GestioneAccount ga= new GestioneAccount();
	private GestioneRobot gr= new GestioneRobot();

	// metodi per i robot
	public Carrello doRetrieveByKeyRobot(String username, int codeRobot) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs;

		Carrello carrello = new Carrello();

		try {
			connection = DriverManagerConnectionPool.getConnection();
			String sql = "SELECT * FROM carrello WHERE email= ? AND codeRobot = ?";
			preparedStatement = connection.prepareStatement(sql);

			preparedStatement.setString(1, username);
			preparedStatement.setInt(2, codeRobot);

			rs = preparedStatement.executeQuery();

			while (rs.next()) {
				carrello.setUsername(rs.getString("email"));
				carrello.setCodeRobot(rs.getInt("codeRobot"));
				carrello.setQuantity(rs.getInt("quantity"));
			}
		} catch (SQLException e) {
			e.printStackTrace();

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				if (connection != null)
					DriverManagerConnectionPool.releaseConnection(connection);
			}
		}

		return carrello;
	}

	public void addRobotInCarrello(String email, Robot robot) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		GestioneAccount ga = new GestioneAccount();

		try {
			connection = DriverManagerConnectionPool.getConnection();
			String sql = "INSERT INTO carrello(email, codeRobot, quantity) values (?, ?, ?);";
			preparedStatement = connection.prepareStatement(sql);

			preparedStatement.setString(1, email);
			preparedStatement.setInt(2, robot.getCode());
			preparedStatement.setString(3, "1");

			preparedStatement.executeUpdate();

			connection.commit();

			RegisteredAccountController.message = "Il robot <b>" + robot.getName()
					+ "</b> � stato aggiunto in modo corretto!";
		} catch (SQLException e) {
			e.printStackTrace();
			RegisteredAccountController.errorMessage = "<b>ERRORE</b>, Il robot non � stato aggiunto!";

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				if (connection != null)
					DriverManagerConnectionPool.releaseConnection(connection);
			}
		}

	}

	public void doUpdateRobot(String username, Robot robot, int quantity) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		String sql = "UPDATE carrello SET quantity = ? WHERE email = ? AND codeRobot = ?";

		try {
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(sql);

			preparedStatement.setInt(1, quantity);
			preparedStatement.setString(2, username);
			preparedStatement.setInt(3, robot.getCode());

			preparedStatement.executeUpdate();

			connection.commit();

			RegisteredAccountController.message = "Il robot <b>" + robot.getName()
					+ "</b> � stato aggiunto in modo corretto!";
		} catch (SQLException e) {
			e.printStackTrace();
			RegisteredAccountController.errorMessage = "<b>ERRORE</b>, Il robot non � stato aggiunto!";

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				if (connection != null)
					DriverManagerConnectionPool.releaseConnection(connection);
			}
		}

	}

	public void removeRobotFromCarrello(String email, Robot robot) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		GestioneAccount ga = new GestioneAccount();

		try {
			connection = DriverManagerConnectionPool.getConnection();
			String sql = "DELETE FROM carrello WHERE codeRobot = ? AND email = ?";
			preparedStatement = connection.prepareStatement(sql);

			preparedStatement.setInt(1, robot.getCode());
			preparedStatement.setString(2, email);

			preparedStatement.executeUpdate();

			connection.commit();

			RegisteredAccountController.message = "Il prodotto <b>" + robot.getName()
					+ "</b> � stato eliminato dal carrello!";
		} catch (SQLException e) {
			e.printStackTrace();
			RegisteredAccountController.errorMessage = "<b>ERRORE</b>, Il prodotto non � stato eliminato dal carrello!";

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				if (connection != null)
					DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	}

	// clear carrello
	public void doDeleteAll(String username) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		try {
			connection = DriverManagerConnectionPool.getConnection();
			String sql = "DELETE FROM carrello WHERE email = ?";
			preparedStatement = connection.prepareStatement(sql);

			preparedStatement.setString(1, username);

			preparedStatement.executeUpdate();

			connection.commit();

			RegisteredAccountController.message = "Il carrello � stato svuotato!";
		} catch (SQLException e) {
			e.printStackTrace();
			RegisteredAccountController.errorMessage = "<b>ERRORE</b>, Il carrello non � stato svuotato.";

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				if (connection != null)
					DriverManagerConnectionPool.releaseConnection(connection);
			}
		}

	}

	public void createOrdine(ArrayList<Carrello> l, String email) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		ArrayList<Ordine> listOrdiniRobot = (ArrayList<Ordine>) ga.visualizzaOrdiniRobot(email);
		Ordine o = new Ordine();

		try {
			connection = DriverManagerConnectionPool.getConnection();
			for (Carrello c : l) {
				o.setEmailCliente(email);
				o.setIdRobot(c.getCodeRobot());
				o.setData_richiesta(new Date(System.currentTimeMillis()));
				o.setQuantit�_scelta(c.getQuantity());
				listOrdiniRobot.add(o);
				String sql = "INSERT INTO ordine(email, idRobot, nameRobot, quantit�_scelta, price, data_richiesta) values (?, ?, ?, ?, ?, ?);";
				preparedStatement = connection.prepareStatement(sql);

				Robot r = gr.findRobotById(""+c.getCodeRobot());
				preparedStatement.setString(1, email);
				preparedStatement.setInt(2, o.getIdRobot());
				preparedStatement.setString(3, r.getName());
				preparedStatement.setInt(4, o.getQuantit�_scelta());
				preparedStatement.setInt(5, Integer.parseInt(r.getPrice()));
				preparedStatement.setDate(6, o.getData_richiesta());

				preparedStatement.executeUpdate();

				connection.commit();

			}
			RegisteredAccountController.message = "L'<b>ordine</b> � stato creato! ";
		} catch (SQLException e) {
			e.printStackTrace();
			RegisteredAccountController.errorMessage = "<b>ERRORE</b>, L'ordine non � stato creato!";

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				if (connection != null)
					DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	}


	// (NON SERVE PI� QUA) mi faccio dare tutti i robot che ha nel carrello questo
	// username
	/*
	 * public ArrayList<Carrello> doRetrieveAll(String username) throws SQLException
	 * { Connection connection = null; PreparedStatement preparedStatement = null;
	 * ResultSet rs = null;
	 * 
	 * ArrayList<Carrello> listProduct = new ArrayList<Carrello>();
	 * 
	 * try { connection = DriverManagerConnectionPool.getConnection(); String sql =
	 * "SELECT * FROM carrello WHERE email = ?"; preparedStatement =
	 * connection.prepareStatement(sql);
	 * 
	 * preparedStatement.setString(1, username);
	 * 
	 * rs = preparedStatement.executeQuery();
	 * 
	 * while (rs.next()) { Carrello carrello = new Carrello();
	 * 
	 * carrello.setUsername(username);
	 * carrello.setCodeRobot(rs.getInt("codeRobot"));
	 * carrello.setQuantity(rs.getInt("quantity"));
	 * 
	 * listProduct.add(carrello); }
	 * 
	 * } catch (SQLException e) { e.printStackTrace(); } finally { try { if
	 * (preparedStatement != null) preparedStatement.close(); } catch (SQLException
	 * e) { e.printStackTrace(); } finally { if (connection != null)
	 * DriverManagerConnectionPool.releaseConnection(connection); } }
	 * 
	 * return listProduct; }
	 */
}
