package it.unisa.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import it.unisa.DriverManagerConnectionPool;

public class GestioneAccount{

	public void registerAccount(Account a) throws SQLException {
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		
		try {
			connection= DriverManagerConnectionPool.getConnection();
			String sql= "INSERT INTO utente values (?, ?, ?, ?, ?);";
			preparedStatement= connection.prepareStatement(sql);
			
			preparedStatement.setString(1, a.getEmail());
			preparedStatement.setString(2, a.getPassword());
			preparedStatement.setString(3, a.getPoints());
			preparedStatement.setString(4, a.getRole());
			preparedStatement.setDate(5, a.getData_di_nascita());
			
			preparedStatement.executeUpdate();
			
			connection.commit();
		} catch (SQLException e) {
			e.printStackTrace();
			
		} finally {
			try {
				if (preparedStatement!=null)
					preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				if (connection!=null)
					DriverManagerConnectionPool.releaseConnection(connection);
			}
		}	
	}
	
	public Account findAccountById(String email) throws SQLException {
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		ResultSet rs;
	
		Account utente= new Account();
		
		try {
			connection= DriverManagerConnectionPool.getConnection();
			String sql="SELECT * FROM utente WHERE email= ?";
			preparedStatement= connection.prepareStatement(sql);
			
			preparedStatement.setString(1, email);
			
			rs= preparedStatement.executeQuery();
			
			while (rs.next()) {
				utente.setEmail(rs.getString("email"));
				utente.setPassword(rs.getString("password"));
				utente.setPoints(rs.getString("punti"));
				utente.setRole(rs.getString("role"));
				utente.setData_di_nascita(rs.getDate("data_di_nascita"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			
		} finally {
			try {
				if (preparedStatement!=null)
					preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				if (connection!=null)
					DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		
		return utente;
	}

	public List<Account> findAllAccount() throws SQLException {
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		ResultSet rs=null;
		
		ArrayList<Account> listUtenti=new ArrayList<Account>();
		
		try {
			connection= DriverManagerConnectionPool.getConnection();
			String sql= "SELECT * FROM utente";
			preparedStatement= connection.prepareStatement(sql);
			
			rs= preparedStatement.executeQuery();
			
			while (rs.next()) {
				Account utente= new Account();

				utente.setEmail(rs.getString("email"));
				utente.setPassword(rs.getString("password"));
				utente.setPoints(rs.getString("punti"));
				utente.setRole(rs.getString("role"));
				utente.setData_di_nascita(rs.getDate("data_di_nascita"));
				
				listUtenti.add(utente);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (preparedStatement!=null)
					preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				if (connection!=null)
					DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		
		return listUtenti;
	}


	public void updateAccount(Account a) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		String sql = "UPDATE utente SET password = ?, punti = ?, role = ?, data_di_nascita= ? WHERE email = ?";
		
		try {
			connection = DriverManagerConnectionPool.getConnection();
			preparedStatement = connection.prepareStatement(sql);	
			
			preparedStatement.setString(1, a.getPassword());
			preparedStatement.setString(2, a.getPoints());
			preparedStatement.setString(3, a.getRole());
			preparedStatement.setDate(4, a.getData_di_nascita());
			preparedStatement.setString(5, a.getEmail());
			
			preparedStatement.executeUpdate();
			
			connection.commit();
			
		} catch (SQLException e) {
			e.printStackTrace();
			
		} finally {
			try {
				if (preparedStatement!=null)
					preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				if (connection!=null)
					DriverManagerConnectionPool.releaseConnection(connection);
			}
		}	
	}

	public Account login(String email, String password) throws SQLException {
		Account a = findAccountById(email);
		System.out.println(a);
		System.out.println("utente database: " + a.getPassword() + "\nusername del sito: " + email + "\npassword del sito: " + password);
		
		if (a.getEmail()!=null && a.getPassword()!=null && email!=null && password!=null)
			if (!a.getEmail().equals("") && !a.getPassword().equals("") && !email.equals("") && !password.equals(""))
				if (a.getPassword().equals(password) && a.getEmail().equals(email))
					return a;
		
		return a;
	}
	

	public List<Carrello> visualizzaCarrello(String email) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;

		ArrayList<Carrello> listProduct = new ArrayList<Carrello>();

		try {
			connection = DriverManagerConnectionPool.getConnection();
			String sql = "SELECT * FROM carrello WHERE email = ?";
			preparedStatement = connection.prepareStatement(sql);

			preparedStatement.setString(1, email);

			rs = preparedStatement.executeQuery();

			while (rs.next()) {
				Carrello carrello = new Carrello();

				carrello.setUsername(email);
				carrello.setCodeRobot(rs.getInt("codeRobot"));
				carrello.setQuantity(rs.getInt("quantity"));

				listProduct.add(carrello);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				if (connection != null)
					DriverManagerConnectionPool.releaseConnection(connection);
			}
		}

		return listProduct;
	}
	
	public List<Ordine> visualizzaOrdiniRobot(String email) throws SQLException {
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		ResultSet rs;

		ArrayList<Ordine> listOrdiniRobot= new ArrayList<Ordine>();
		
		try {
			connection= DriverManagerConnectionPool.getConnection();
			String sql="SELECT * FROM ordine WHERE email= ?";
			preparedStatement= connection.prepareStatement(sql);
			
			preparedStatement.setString(1, email);
			
			rs= preparedStatement.executeQuery();
			
			while (rs.next()) {
				Ordine o= new Ordine();

				o.setCodeOrdine(rs.getInt("codeOrdine"));
				o.setEmailCliente(rs.getString("email"));
				o.setIdRobot(rs.getInt("idRobot"));
				o.setNameRobot(rs.getString("nameRobot"));
				o.setQuantit�_scelta(rs.getInt("quantit�_scelta"));
				o.setPrice(rs.getInt("price"));
				o.setData_richiesta(rs.getDate("data_richiesta"));
				
				listOrdiniRobot.add(o);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			
		} finally {
			try {
				if (preparedStatement!=null)
					preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				if (connection!=null)
					DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		
		return listOrdiniRobot;
	}
	
	public List<PremioInOrdine> visualizzaOrdiniPremi(String email) throws SQLException {
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		ResultSet rs;

		ArrayList<PremioInOrdine> listOrdiniPremi= new ArrayList<PremioInOrdine>();
		
		try {
			connection= DriverManagerConnectionPool.getConnection();
			String sql="SELECT * FROM premioInOrdine WHERE email= ?";
			preparedStatement= connection.prepareStatement(sql);
			
			preparedStatement.setString(1, email);
			
			rs= preparedStatement.executeQuery();
			
			while (rs.next()) {
				PremioInOrdine o= new PremioInOrdine();

				o.setCodeOrdine(rs.getInt("codeOrdine"));
				o.setEmailCliente(rs.getString("email"));
				o.setIdPremio(rs.getString("idPremio"));
				o.setQuantit�_scelta(rs.getInt("quantit�_scelta"));
				o.setPunti(rs.getInt("punti"));
				o.setData_richiesta(rs.getDate("data_richiesta"));
				
				listOrdiniPremi.add(o);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			
		} finally {
			try {
				if (preparedStatement!=null)
					preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				if (connection!=null)
					DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		
		return listOrdiniPremi;
	}
	
	private void deleteUtente(Account utente) throws SQLException {
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		
		try {
			connection= DriverManagerConnectionPool.getConnection();
			String sql= "DELETE FROM utente WHERE email= ?";
			preparedStatement= connection.prepareStatement(sql);
			
			preparedStatement.setString(1, utente.getEmail());
			
			preparedStatement.executeUpdate();

			connection.commit();
		} catch (SQLException e) {
			e.printStackTrace();
			
		} finally {
			try {
				if (preparedStatement!=null)
					preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				if (connection!=null)
					DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
	}

}
