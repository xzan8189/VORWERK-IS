package it.unisa.model;

import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Robot {
	// variabili d'istanza
	private int code;
	private String name;
	private String description;
	private String price;
	private String quantity;

	// metodi costruttori
	public Robot() {
		this.code = -1;
		this.name = "";
		this.description = "";
		this.price = "";
		this.quantity = "";
	}

	public Robot(int code, String name, String description, String price, String quantity) {
		this.code = code;
		this.name = name;
		this.description = description;
		this.price = price;
		this.quantity = quantity;
	}

	// metodi d'accesso
	public int getCode() {
		return this.code;
	}

	public String getName() {
		return name;
	}

	public String getDescription() {
		return description;
	}

	public String getPrice() {
		return price;
	}

	public String getQuantity() {
		return quantity;
	}

	// metodi modificatori
	public void setCode(int code) {
		this.code = code;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	// metodi di validazione dei campi
	public boolean validateNome(String name) {
		String regex = "[A-Z a-z 0-9 ^\\n]{5,30}";
		Pattern pt = Pattern.compile(regex);
		Matcher mt = pt.matcher(name);
		boolean res = mt.matches();
		if (res)
			System.out.println("S�, matcha! nome: " + name);
		else
			System.out.println("Non matcha, nome: " + name);

		return res;
	}

	public boolean validateDescrizione(String description) {
		String regex = "[A-Z a-z 0-9 . , ! ? % ^\\n]{5,255}";
		Pattern pt = Pattern.compile(regex);
		Matcher mt = pt.matcher(description);
		boolean res = mt.matches();
		if (res)
			System.out.println("S�, matcha! description: " + description);
		else
			System.out.println("Non matcha, description: " + description);

		return res;
	}

	public boolean validatePrezzo(String price) {
		String regex = "[0-9]{1,3}";
		Pattern pt = Pattern.compile(regex);
		Matcher mt = pt.matcher(price);
		boolean res = mt.matches();
		if (res) {
			if (Integer.parseInt(price) <= 0) {
				System.out.println("Non matcha, prezzo: " + price + "\n");
				return false;
			} else
				System.out.println("S�, matcha! prezzo: " + price + "\n");
		} else
			System.out.println("Non matcha, prezzo: " + price + "\n");

		return res;
	}

	public boolean validateQuantit�Disponibile(String quantity) {
		String regex = "[0-9]{1,3}";
		Pattern pt = Pattern.compile(regex);
		Matcher mt = pt.matcher(quantity);
		boolean res = mt.matches();
		if (res) {
			if (Integer.parseInt(quantity) <= 0) {
				System.out.println("Non matcha, quantit� disponibile: " + quantity + "\n");
				return false;
			} else
				System.out.println("S�, matcha! quantit� disponibile: " + quantity + "\n");
		} else
			System.out.println("Non matcha, quantit� disponibile: " + quantity + "\n");

		return res;
	}

	public String validateRobot() {
		String res = "";
		System.out.println();
		if (name != null && !validateNome(name)) /* validate name */
			res += "Il nome: <b>" + name + "</b> non � valido<br>";

		if (description != null && !validateDescrizione(description)) /* validate descrizione */
			res += "<b>La descrizione</b> non � valida<br>";

		if (price != null && !validatePrezzo(price)) /* validate prezzo */
			res += "Il prezzo: <b>" + price + "</b> non � valido<br>";

		if (quantity != null && !validateQuantit�Disponibile(quantity)) /* validate quantit� disponibile */
			res += "La quantit� disponibile: <b>" + quantity + "</b> non � valida<br>";

		return res;
	}

	// metodi sovrascritti
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof Robot))
			return false;
		Robot other = (Robot) obj;
		return code == other.code && Objects.equals(description, other.description) && Objects.equals(name, other.name)
				&& Objects.equals(price, other.price) && Objects.equals(quantity, other.quantity);
	}

	@Override
	public String toString() {
		return "Robot [code=" + code + ", name=" + name + ", description=" + description + ", price=" + price
				+ ", quantity=" + quantity + "]";
	}

}// fine classe
