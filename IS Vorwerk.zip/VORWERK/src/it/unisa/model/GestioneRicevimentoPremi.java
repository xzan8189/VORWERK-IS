package it.unisa.model;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

import it.unisa.DriverManagerConnectionPool;
import it.unisa.control.Controller;

public class GestioneRicevimentoPremi {
	//variabili d'istanza
	private GestioneAccount ga= new GestioneAccount();
	
	public void createOrdine(Premio p, String email) throws SQLException {
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		
		try {
			connection= DriverManagerConnectionPool.getConnection();
			String sql= "INSERT INTO premioInOrdine(email, idPremio, quantit�_scelta, punti, data_richiesta) values (?, ?, ?, ?, ?);";
			preparedStatement= connection.prepareStatement(sql);
			
			preparedStatement.setString(1, email);
			preparedStatement.setString(2, p.getName());
			preparedStatement.setInt(3, 1);
			preparedStatement.setInt(4, Integer.parseInt(p.getPunti()));
			preparedStatement.setDate(5, new Date(System.currentTimeMillis()));
			
			preparedStatement.executeUpdate();

			connection.commit();
			
			Controller.message="L'ordine del premio � stato creato!";
		} catch (SQLException e) {
			e.printStackTrace();
			Controller.errorMessage="<b>ERRORE</b>, L'ordine del premio non � stato creato!";
			
		} finally {
			try {
				if (preparedStatement!=null)
					preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				if (connection!=null)
					DriverManagerConnectionPool.releaseConnection(connection);
			}
		}	
	}

}
