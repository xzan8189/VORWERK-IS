package it.unisa.model;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.Period;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Account {
	// variabili d'istanza
	private String email;
	private String password;
	private String points;
	private String role; // ACCOUNT oppure ADMINISTRATOR //CLIENTE, GESTOREROBOT, GESTOREPREMI

	public enum Ruoli {
		CLIENTE, GESTOREROBOT, GESTOREPREMI
	};

	private java.sql.Date data_di_nascita;

	// metodi costruttori
	public Account() {
		this.email = "";
		this.password = "";
		this.points = "-1";
		this.role = "";
	}

	public Account(String email, String password, String points, String role) {
		this.email = (email == null ? "" : email);
		this.password = (password == null ? "" : password);
		this.points = (points == null ? "" : points);
		this.role = (role == null ? "" : role);
	}

	/*
	 * Questo di sotto sar� il metodo costruttore che userai da ora in
	 * avanti(soprattutto per la registrazione di un nuovo utente
	 */
	public Account(String email, String password, String points, String role, java.sql.Date data_di_nascita) {
		this.email = email;
		this.password = password;
		this.points = points;
		this.role = role;
		this.data_di_nascita = data_di_nascita;
	}

	// metodi d'accesso
	public String getEmail() {
		return email;
	}

	public String getPassword() {
		return password;
	}

	public String getPoints() {
		return points;
	}

	public String getRole() {
		return role;
	}

	public java.sql.Date getData_di_nascita() {
		return data_di_nascita;
	}

	// metodi modificatori
	public void setEmail(String email) {
		this.email = email;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setPoints(String points) {
		this.points = points;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public void setData_di_nascita(java.sql.Date data_di_nascita) {
		this.data_di_nascita = data_di_nascita;
	}

	// metodi di validazione dei campi
	public boolean validateEmail(String email) {
		String regex = "[A-z 0-9\\.\\+_-]+@[A-z 0-9\\._-]+\\.[A-z]{2,3}";
		Pattern pt = Pattern.compile(regex);
		Matcher mt = pt.matcher(email);
		boolean res = mt.matches();
		if (res)
			System.out.println("S�, matcha! email: " + email);
		else
			System.out.println("Non matcha, email: " + email);

		return res;
	}

	public boolean validatePassword(String password) {
		String regex = "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z]).{8,20})";
		Pattern pt = Pattern.compile(regex);
		Matcher mt = pt.matcher(password);
		boolean res = mt.matches();
		if (res)
			System.out.println("S�, matcha! password: " + password);
		else
			System.out.println("Non matcha, password: " + password);

		return res;
	}

	public boolean validateData_di_nascita(String data_di_nascita) throws ParseException {
		String regex = "([12]\\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01]))"; // [yyyy/mm/dd]=
																				// ([12]\d{3}(\/)(0[1-9]|1[0-2])(\/)(0[1-9]|[12]\d|3[01]))
		Pattern pt = Pattern.compile(regex);
		Matcher mt = pt.matcher(data_di_nascita);
		boolean res = mt.matches();
		if (res) { //controllo se � maggiorenne
			Calendar c= Calendar.getInstance();
			c.setTime(parseDateFromString(data_di_nascita));
			LocalDate dataDiNascita;
			try {
				dataDiNascita = LocalDate.of(c.get(Calendar.YEAR), c.get(Calendar.MONTH)+1, c.get(Calendar.DAY_OF_MONTH));
			} catch (DateTimeException e) {
				e.printStackTrace();
				return false;
			}
			LocalDate now = LocalDate.now();
			long years = ChronoUnit.YEARS.between(dataDiNascita, now);
			System.out.println("years between: " + years);
			if (years >= 18)
				System.out.println("S�, matcha! data_di_nascita: " + data_di_nascita + "\n");
			else {
				System.out.println("Non, matcha, non sei maggiorenne! data_di_nascita: " + data_di_nascita + "\n");
				return false;
			}
		} else
			System.out.println("Non matcha, data_di_nascita: " + data_di_nascita + "\n");

		return res;
	}

	public String validateAccountForRegistration() throws ParseException {
		String res = "";
		System.out.println();
		if (email != null && !validateEmail(email)) /* validate email */
			res += "L'email: <b>" + email + "</b> non � valida<br>";

		if (password != null && !validatePassword(password)) /* validate password */
			res += "La password: <b>" + password + "</b> non � valida<br>";

		if (data_di_nascita != null && !validateData_di_nascita(data_di_nascita.toString())) /* validate data_di_nascita */
			res += "La data di nascita: <b>" + data_di_nascita + "</b> non � valida oppure non sei maggiorenne<br>";

		return res;
	}

	// altri metodi d'appoggio
	private Date parseDateFromString(String data_di_nascita) throws ParseException {
		SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd");
		java.util.Date date = f.parse(data_di_nascita);

		return new Date(date.getTime());
	}

	// metodi sovrascritti
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof Account))
			return false;
		Account other = (Account) obj;
		return Objects.equals(data_di_nascita, other.data_di_nascita) && Objects.equals(email, other.email)
				&& Objects.equals(password, other.password) && Objects.equals(points, other.points)
				&& Objects.equals(role, other.role);
	}

	@Override
	public String toString() {
		return "Utente [email=" + email + ", password=" + password + ", points=" + points + ", role=" + role
				+ ", data_di_nascita=" + data_di_nascita + "]";
	}

} // fine classe
