package it.unisa.model;

import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Premio {
	// variabili d'istanza
	private String name;
	private String description;
	private String punti;
	private String quantity;

	// metodi costruttori
	public Premio() {
		this.name = "-1";
		this.description = "";
		this.punti = "";
		this.quantity = "";
	}

	public Premio(String name, String description, String punti, String quantity) {
		this.name = (name == null ? "" : name);
		this.description = (description == null ? "" : description);
		this.punti = (punti == null ? "" : punti);
		this.quantity = (quantity == null ? "" : quantity);
	}

	// metodi d'accesso
	public String getName() {
		return name;
	}

	public String getDescription() {
		return description;
	}

	public String getPunti() {
		return punti;
	}

	public String getQuantity() {
		return quantity;
	}

	// metodi modificatori
	public void setName(String name) {
		this.name = name;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setPunti(String punti) {
		this.punti = punti;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	// metodi di validazione dei campi
	public boolean validateNome(String name) {
		String regex = "[A-Z a-z 0-9 ^\\n]{5,30}";
		Pattern pt = Pattern.compile(regex);
		Matcher mt = pt.matcher(name);
		boolean res = mt.matches();
		if (res)
			System.out.println("S�, matcha! nome: " + name);
		else
			System.out.println("Non matcha, nome: " + name);

		return res;
	}

	public boolean validateDescrizione(String description) {
		String regex = "[A-Z a-z 0-9 . , ! ? % ^\\n]{5,255}";
		Pattern pt = Pattern.compile(regex);
		Matcher mt = pt.matcher(description);
		boolean res = mt.matches();
		if (res)
			System.out.println("S�, matcha! description: " + description);
		else
			System.out.println("Non matcha, description: " + description);

		return res;
	}

	public boolean validatePunti(String punti) {
		String regex = "[0-9]{1,3}";
		Pattern pt = Pattern.compile(regex);
		Matcher mt = pt.matcher(punti);
		boolean res = mt.matches();
		if (res) {
			if (Integer.parseInt(punti) <= 0) {
				System.out.println("Non matcha, punti: " + punti + "\n");
				return false;
			} else
				System.out.println("S�, matcha! punti: " + punti + "\n");
		} else
			System.out.println("Non matcha, punti: " + punti + "\n");

		return res;
	}

	public boolean validateQuantit�Disponibile(String quantity) {
		String regex = "[0-9]{1,3}";
		Pattern pt = Pattern.compile(regex);
		Matcher mt = pt.matcher(quantity);
		boolean res = mt.matches();
		if (res) {
			if (Integer.parseInt(quantity)<=0) {
				System.out.println("Non matcha, quantit� disponibile: " + quantity + "\n");
				return false;
			} else
				System.out.println("S�, matcha! quantit� disponibile: " + quantity + "\n");
		} else
			System.out.println("Non matcha, quantit� disponibile: " + quantity + "\n");

		return res;
	}

	public String validatePremio() {
		String res = "";
		System.out.println();
		if (name != null && !validateNome(name)) /* validate name */
			res += "Il nome: <b>" + name + "</b> non � valido<br>";

		if (description != null && !validateDescrizione(description)) /* validate descrizione */
			res += "<b>La descrizione</b> non � valida<br>";

		if (punti != null && !validatePunti(punti)) /* validate punti */
			res += "I punti: <b>" + punti + "</b> non sono validi<br>";

		if (quantity != null && !validateQuantit�Disponibile(quantity)) /* validate quantit� disponibile */
			res += "La quantit� disponibile: <b>" + quantity + "</b> non � valida<br>";

		return res;
	}

	// metodi sovrascritti
	@Override
	public String toString() {
		return "Premio [name=" + name + ", description=" + description + ", punti=" + punti + ", quantity=" + quantity
				+ "]";
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof Premio))
			return false;
		Premio other = (Premio) obj;
		return Objects.equals(description, other.description) && Objects.equals(name, other.name)
				&& Objects.equals(punti, other.punti) && Objects.equals(quantity, other.quantity);
	}

}
