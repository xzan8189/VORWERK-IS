package it.unisa.model;

import java.sql.Date;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Ordine {
	//variabili d'istanza
	private int codeOrdine;
	private int idRobot;
	private String nameRobot;
	private String emailCliente;
	private Date data_richiesta;
	private int quantit�_scelta;
	private int price;
	
	//metodi costruttori
	public Ordine() {
		/*	vuoto*/
	}

	public Ordine(int codeOrdine, int idRobot, String nameRobot, String emailCliente, Date data_richiesta,
			int quantit�_scelta, int price) {
		this.codeOrdine = codeOrdine;
		this.idRobot = idRobot;
		this.nameRobot = nameRobot;
		this.emailCliente = emailCliente;
		this.data_richiesta = data_richiesta;
		this.quantit�_scelta = quantit�_scelta;
		this.price = price;
	}

	//metodi d'accesso
	public int getCodeOrdine() {
		return codeOrdine;
	}
	
	public int getIdRobot() {
		return idRobot;
	}

	public String getEmailCliente() {
		return emailCliente;
	}

	public Date getData_richiesta() {
		return data_richiesta;
	}

	public int getQuantit�_scelta() {
		return quantit�_scelta;
	}

	public String getNameRobot() {
		return nameRobot;
	}

	public int getPrice() {
		return price;
	}
	//metodi modificatori
	public void setCodeOrdine(int codeOrdine) {
		this.codeOrdine = codeOrdine;
	}
	
	public void setIdRobot(int idRobot) {
		this.idRobot = idRobot;
	}

	public void setNameRobot(String nameRobot) {
		this.nameRobot = nameRobot;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public void setEmailCliente(String emailCliente) {
		this.emailCliente = emailCliente;
	}

	public void setData_richiesta(Date data_richiesta) {
		this.data_richiesta = data_richiesta;
	}

	public void setQuantit�_scelta(int quantit�_scelta) {
		this.quantit�_scelta = quantit�_scelta;
	}

	// metodi di validazione dei campi
	public boolean validateEmailCliente(String emailCliente) {
		String regex = "[A-z 0-9\\.\\+_-]+@[A-z 0-9\\._-]+\\.[A-z]{2,3}";
		Pattern pt = Pattern.compile(regex);
		Matcher mt = pt.matcher(emailCliente);
		boolean res = mt.matches();
		if (res)
			System.out.println("S�, matcha! email: " + emailCliente);
		else
			System.out.println("Non matcha, email: " + emailCliente);

		return res;
	}

	public boolean validateIdRobot(String idRobot) {
		String regex = "[0-9]";
		Pattern pt = Pattern.compile(regex);
		Matcher mt = pt.matcher(idRobot);
		boolean res = mt.matches();
		if (res)
			System.out.println("S�, matcha! idRobot: " + idRobot);
		else
			System.out.println("Non matcha, idRobot: " + idRobot);

		return res;
	}

	public boolean validateData_richiesta(String data_richiesta) {
		String regex = "([12]\\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01]))";
		Pattern pt = Pattern.compile(regex);
		Matcher mt = pt.matcher(data_richiesta);
		boolean res = mt.matches();
		if (res)
			System.out.println("S�, matcha! data_richiesta: " + data_richiesta + "\n");
		else
			System.out.println("Non matcha, data_richiesta: " + data_richiesta + "\n");

		return res;
	}
	
	public boolean validateQuantit�Scelta(String quantit�_scelta) {
		String regex = "[0-9]{1,3}";
		Pattern pt = Pattern.compile(regex);
		Matcher mt = pt.matcher(quantit�_scelta);
		boolean res = mt.matches();
		if (res)
			System.out.println("S�, matcha! quantit� scelta: " + quantit�_scelta + "\n");
		else
			System.out.println("Non matcha, quantit� scelta: " + quantit�_scelta + "\n");

		return res;
	}

	public String validateOrdine() {
		String res = "";
		System.out.println();
		if (emailCliente!=null && !validateEmailCliente(emailCliente)) /*validate emailCliente*/
			res += "L'email: <b>" + emailCliente + "</b> non � valida<br>";
		
		if (String.valueOf(idRobot)!=null && !validateIdRobot(String.valueOf(idRobot))) /*validate idRobot*/
			res += "La password: <b>" + idRobot + "</b> non � valida<br>";
		
		if (data_richiesta!=null && !validateData_richiesta(data_richiesta.toString())) /*validate data_richiesta*/
			res += "La data di richiesta: <b>" + data_richiesta + "</b> non � valida<br>";

		if (String.valueOf(quantit�_scelta)!=null && !validateQuantit�Scelta(String.valueOf(quantit�_scelta))) /*validate quantit�_scelta*/
			res += "La quantit� scleta: <b>" + quantit�_scelta + "</b> non � valida<br>";
		return res;
	}
	
	//metodi sovrascritti
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof Ordine))
			return false;
		Ordine other = (Ordine) obj;
		return codeOrdine == other.codeOrdine && Objects.equals(data_richiesta, other.data_richiesta)
				&& Objects.equals(emailCliente, other.emailCliente) && idRobot == other.idRobot
				&& quantit�_scelta == other.quantit�_scelta;
	}

	@Override
	public String toString() {
		return "Ordine [codeOrdine=" + codeOrdine + ", idRobot=" + idRobot + ", emailCliente=" + emailCliente
				+ ", data_richiesta=" + data_richiesta + ", quantit�_scelta=" + quantit�_scelta + "]";
	}


	
	
	
	
	
	
	
	
	
	
}//fine classe













