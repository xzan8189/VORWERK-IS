package it.unisa.control;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import it.unisa.model.GestioneAccount;
import it.unisa.model.Ordine;
import it.unisa.model.Premio;
import it.unisa.model.PremioInOrdine;
import it.unisa.model.GestionePremio;
import it.unisa.model.GestioneRobot;
import it.unisa.model.Robot;
import it.unisa.model.Account;

@WebServlet("/ProfiloController")
public class ProfiloController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	// variabili d'istanza
	private GestioneAccount ga = new GestioneAccount();
	private GestioneRobot gr= new GestioneRobot();
	private GestionePremio gp= new GestionePremio();

	public ProfiloController() {
		super();
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("action");
		HttpSession currentSession = request.getSession();
		String email = (String) currentSession.getAttribute("user");
		System.out.println("email: " + email);
		
		try {
			if (action != null && !action.equals("")) {
				if (action.equals("takeListOrdini")) { //Prende gli ordini dei robot e dei premi
					ArrayList<Ordine> listRobotInOrdini = (ArrayList<Ordine>) ga.visualizzaOrdiniRobot(email);
					ArrayList<PremioInOrdine> listPremiInOrdini= (ArrayList<PremioInOrdine>) ga.visualizzaOrdiniPremi(email);
					ArrayList<Robot> listRobot= new ArrayList<Robot>();
					for (Ordine o : listRobotInOrdini) {
						listRobot.add(gr.findRobotById(""+o.getIdRobot()));
					}
					ArrayList<Premio> listPremi= new ArrayList<Premio>();
					for (PremioInOrdine pio : listPremiInOrdini) {
						listPremi.add(gp.findPremioById(pio.getIdPremio()));
					}
						
					request.setAttribute("listRobotInOrdini", listRobotInOrdini);
					request.setAttribute("listPremiInOrdini", listPremiInOrdini);
					request.setAttribute("listRobot", listRobot);
					request.setAttribute("listPremi", listPremi);
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		RequestDispatcher view = request.getRequestDispatcher("/account/profilo.jsp");
		view.forward(request, response);
		return;
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
