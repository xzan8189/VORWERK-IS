package it.unisa.control;

import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import it.unisa.model.Carrello;
import it.unisa.model.GestioneAcquistoRobot;
import it.unisa.model.GestioneRicevimentoPremi;
import it.unisa.model.Premio;
import it.unisa.model.GestionePremio;
import it.unisa.model.GestioneRobot;
import it.unisa.model.Robot;
import it.unisa.model.Account;
import it.unisa.model.GestioneAccount;
import it.unisa.model.Ordine;

/**
 * Servlet implementation class RegisteredAccountController
 */
@WebServlet("/RegisteredAccountController")
public class RegisteredAccountController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static GestioneAcquistoRobot modelCarrello = new GestioneAcquistoRobot();
	static GestioneRobot modelRobot = new GestioneRobot();
	static GestionePremio modelAward =  new GestionePremio();
	static GestioneAccount modelUtente = new GestioneAccount();
	static GestioneRicevimentoPremi grp= new GestioneRicevimentoPremi();
	public static String idNameAward=null;
	public static String message=null;
	public static String errorMessage=null;

	public RegisteredAccountController() {
		super();
	}

	@SuppressWarnings("unchecked")
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("action");
		HttpSession currentSession = request.getSession();
		String username = (String) currentSession.getAttribute("user");
		String codeRobot = request.getParameter("codeRobot");
		System.out.println("User: " + username);

		try {
			if (action != null && !action.equals("")) {
				if (action.equalsIgnoreCase("addCarrelloRobot")) {
					this.addCarrelloRobot(request, username);
					
				} else if (action.equalsIgnoreCase("buyAward")) {
					//da completare
					String codeAward = request.getParameter("codeAward");
					Account utente= modelUtente.findAccountById(username);
					Premio premio= modelAward.findPremioById(codeAward);
					RegisteredAccountController.idNameAward= codeAward;
					int puntiUtente= Integer.parseInt(utente.getPoints());
					int puntiPremio= Integer.parseInt(premio.getPunti());
					
					//Controllo se pu� comprare il premio e quindi aggiorno sia la quantit� del premio disponibile e poi i punti dell'utente
					if (puntiUtente>=puntiPremio && Integer.parseInt(premio.getQuantity())>0) {
						int quantity= Integer.parseInt(premio.getQuantity()) - 1;
						premio.setQuantity(""+quantity);
						System.out.println("quantity premio: " + quantity);
						modelAward.updatePremio(premio);
						
						int newPuntiUtente= puntiUtente - puntiPremio;
						System.out.println("codeAward :" + codeAward + "\nnewPuntiUtente: " + newPuntiUtente + "\npuntiUtente: " + puntiUtente + "\npuntiPremio: " + puntiPremio + "\n");
						utente.setPoints(""+newPuntiUtente);
						modelUtente.updateAccount(utente);
						
						//Creo l'ordine del premio
						grp.createOrdine(premio, username);

						request.setAttribute("message", "La compera del premio � andata a buon fine!");
						request.setAttribute("errorMessage", RegisteredAccountController.errorMessage);
						RegisteredAccountController.errorMessage=null;
						RegisteredAccountController.message=null;
					} else {
						request.setAttribute("errorMessage", "Non hai abbastanza <b>Punti</b>!");
						RegisteredAccountController.errorMessage=null;
						RegisteredAccountController.message=null;
					}

					request.removeAttribute("points");
					request.removeAttribute("listPremi");
					request.setAttribute("points", modelUtente.findAccountById(username).getPoints());
					request.setAttribute("listPremi", modelAward.findAllPremi(""));


					RequestDispatcher view = request.getRequestDispatcher("/account/premi.jsp");
					view.forward(request, response);
					return;
					
				} else if (action.equalsIgnoreCase("buyAll")) {
					ArrayList<Carrello> carrello = (ArrayList<Carrello>) modelUtente.visualizzaCarrello(username);
					
					//calcolo i punti
					int somma=0;
					for (Carrello robot: carrello) {
						somma += 350 * robot.getQuantity();
					}
					
					//aggiorno i punti all'utente
					Account utente= modelUtente.findAccountById(username);
					int points= Integer.parseInt(utente.getPoints()) + somma;
					utente.setPoints(""+points);
					modelUtente.updateAccount(utente);
					
					//Creo l'ordine dei robot comprati	
					modelCarrello.createOrdine(carrello, username);
					
					//elimino tutto dal carrello perch� ha comprato
					modelCarrello.doDeleteAll(username);
					
					request.setAttribute("message", "La compera � andata a buon fine!");
					request.setAttribute("errorMessage", RegisteredAccountController.errorMessage);
					RegisteredAccountController.errorMessage=null;
					RegisteredAccountController.message=null;
					
				} else if (action.equalsIgnoreCase("delete")) {
					Robot robot= modelRobot.findRobotById(request.getParameter("code"));
					Carrello productInCarrello = modelCarrello.doRetrieveByKeyRobot(username, robot.getCode());
					int quantity= Integer.parseInt(robot.getQuantity()) + productInCarrello.getQuantity();
					robot.setQuantity(""+quantity);

					modelRobot.updateRobot(robot);
					modelCarrello.removeRobotFromCarrello(username, robot);

					request.setAttribute("message", RegisteredAccountController.message);
					request.setAttribute("errorMessage", RegisteredAccountController.errorMessage);
					RegisteredAccountController.errorMessage=null;
					RegisteredAccountController.message=null;
					
				} else if(action.equalsIgnoreCase("clear")) {
					ArrayList<Carrello> carrello= (ArrayList<Carrello>) modelUtente.visualizzaCarrello(username);
					
					for(int i=0; i<carrello.size(); i++) {
						Robot robot= modelRobot.findRobotById(""+carrello.get(i).getCodeRobot());
						int quantity= Integer.parseInt(robot.getQuantity()) + carrello.get(i).getQuantity();
						robot.setQuantity(""+quantity);
						
						modelRobot.updateRobot(robot);
						modelCarrello.doDeleteAll(username);
					}
					
					request.setAttribute("message", RegisteredAccountController.message);
					request.setAttribute("errorMessage", RegisteredAccountController.errorMessage);
					RegisteredAccountController.errorMessage=null;
					RegisteredAccountController.message=null;
					
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		
		//carrello, punti e robot(cio� i robot che stanno nel carrello dell'utente)
		try {
			request.removeAttribute("carrello");
			request.removeAttribute("robots");
			request.removeAttribute("listPremi");
			request.removeAttribute("listRobot");
			
			ArrayList<Carrello> prova= (ArrayList<Carrello>) modelUtente.visualizzaCarrello(username);
			ArrayList<Robot> robots= new ArrayList<Robot>();
			for (Carrello product : prova) { //sto prendendo i prodotti dal carrello per farmi avere la lista dei robot dell'utente
				robots.add(modelRobot.findRobotById(""+product.getCodeRobot()));
			}
			
			request.setAttribute("carrello", prova);
			request.setAttribute("robots", robots);
			request.setAttribute("listPremi", modelAward.findAllPremi(""));
			request.setAttribute("listRobot", modelRobot.findAllRobot(""));
			
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("nessun carrello");
		}
		
		//capire a chi fare il dispatch delle liste
		if (action!=null && !action.equalsIgnoreCase("")) {
			if (username!=null && action.equalsIgnoreCase("dispatchPremiLogged")) {
				try {
					request.removeAttribute("points");
					request.setAttribute("points", modelUtente.findAccountById(username).getPoints());
					
					RequestDispatcher view = request.getRequestDispatcher("/account/premi.jsp");
					view.forward(request, response);
					return;
					
				} catch (SQLException e) {
					e.printStackTrace();
				}
			} else if (action.equalsIgnoreCase("dispatchPremi")) {
				RequestDispatcher view = request.getRequestDispatcher("/account/premi.jsp");
				view.forward(request, response);
				return;
				
			} else if (action.equalsIgnoreCase("dispatchRobot")) {
				RequestDispatcher view = request.getRequestDispatcher("/account/robot.jsp");
				view.forward(request, response);
				return;
				
			}
		}
		
		RequestDispatcher view = request.getRequestDispatcher("/account/carrello.jsp");
		view.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	
	//metodi d'appoggio per tutti i controlli dovuti dall'inserimento di un robot nel carrello
	private void addCarrelloRobot(ServletRequest request, String username) throws NumberFormatException, SQLException {
		String codeRobot = request.getParameter("codeRobot");
		
		System.out.println("add carrello robot");
		Carrello carrello = modelCarrello.doRetrieveByKeyRobot(username, Integer.parseInt(codeRobot));
		System.out.println("username del carrello:" + carrello.getUsername() + "\nusername della sessione:" + username);
		if (!carrello.getUsername().equalsIgnoreCase("")) {
			System.out.println("modificare il prodotto");
			// significa che il prodotto � gi� � nel carrello e quindi bisogna solo
			// aggiornare la quantit�

			// aggiungo quantit� +1 al prodotto nel carrello
			Robot robot = modelRobot.findRobotById("" + carrello.getCodeRobot());
			if (Integer.parseInt(robot.getQuantity()) > 0) {
				modelCarrello.doUpdateRobot(username, robot, carrello.getQuantity() + 1);

				// diminuisco la quantit� di uno del prodotto nel negozio
				robot.setQuantity(String.valueOf(Integer.parseInt(robot.getQuantity()) - 1));
				modelRobot.updateRobot(robot);
				System.out.println("prodotto aggiornato anche nello store\n\n");
				
				request.setAttribute("message", RegisteredAccountController.message);
				request.setAttribute("errorMessage", RegisteredAccountController.errorMessage);
				RegisteredAccountController.errorMessage=null;
				RegisteredAccountController.message=null;
				
			} else { //non � possibile aggiungere il robot al carrello
				System.out.println("\n\n");
				request.setAttribute("message", RegisteredAccountController.message);
				request.setAttribute("errorMessage", "Il prodotto � esaurito");
				RegisteredAccountController.errorMessage=null;
				RegisteredAccountController.message=null;
			}
		} else {
			System.out.println("aggiungere completamente il prodotto");
			// significa che il prodotto non lo tiene nel carrello e quindi bisogna
			// aggiungerlo

			// aggiungo il nuovo prodotto acquistato
			Robot robot = modelRobot.findRobotById("" + codeRobot);
			System.out.println("codeRobot:" + robot.getCode());
			if (Integer.parseInt(robot.getQuantity()) > 0) {
				modelCarrello.addRobotInCarrello(username, robot);
				System.out.println("prodotto salvato nel carrello");
				
				// diminuisco la quantit� di uno del prodotto nel negozio
				robot.setQuantity(String.valueOf(Integer.parseInt(robot.getQuantity()) - 1));
				modelRobot.updateRobot(robot);
				System.out.println("prodotto aggiornato anche nello store\n\n");
				
				request.setAttribute("message", RegisteredAccountController.message);
				request.setAttribute("errorMessage", RegisteredAccountController.errorMessage);
				RegisteredAccountController.errorMessage=null;
				RegisteredAccountController.message=null;
				
			} else { //non � possibile aggiungere il robot al carrello
				System.out.println("\n\n");
				request.setAttribute("message", RegisteredAccountController.message);
				request.setAttribute("errorMessage", "Il prodotto � esaurito");
				RegisteredAccountController.errorMessage=null;
				RegisteredAccountController.message=null;
			}
		}
		
	}
}
