package it.unisa.control;

import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.mail.MessagingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import it.unisa.MailUtility;
import it.unisa.model.Account;
import it.unisa.model.GestioneAccount;

@WebServlet("/RegistrazioneController")
public class RegistrazioneController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	// variabili d'istanza
	GestioneAccount ga = new GestioneAccount();

	public RegistrazioneController() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("action");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		String data_di_nascita = request.getParameter("data_di_nascita");
		String result = "";

		try {
			if (action != null && !action.equals("")) {
				if (action.equals("checkRegistration")) {
					Account a = new Account();
					a.setEmail(email);
					a.setPassword(password);
					try {
						a.setData_di_nascita(parseDateFromString(data_di_nascita));
						result = a.validateAccountForRegistration(); /* vedo se � valida la creazione dell'account */
					} catch (ParseException e1) {
						System.err.println("ERROR: " + e1.getMessage());
						result += "La data di nascita: <b>" + data_di_nascita + "</b> non � valida\n";
					}

					/* controllo gli errori e nel caso li stampo in registrazione.jsp */
					if (!result.equals(""))
						request.setAttribute("errorMessage", result);

					else {//Il controllo del formato � andato a buon fine
						//e quindi controllo se esiste gi� l'account(controllando l'email)
						Account aFound = ga.findAccountById(email);
						if (aFound.getEmail() != null && !aFound.getEmail().equals("")) {
							System.out.println(aFound);
							request.setAttribute("errorMessage", "Questa email: <b>" + email + "</b> gi� esiste!!\n");
							
						} else {
							//La registrazione pu� avvenire 
							//Invio l'email per la registrazione
							try {
								MailUtility.sendEmail(email, "Registrazione", "Ecco il link per effettuare la registrazione al sito:\n"
										+ "http://localhost:8080/VORWERK/RegistrazioneController?action=registration"
										+ "&email=" + email 
										+ "&password=" + password + "&data_di_nascita=" + data_di_nascita);
								request.setAttribute("message", "Ti � stata inviata un'email per la conferma della registrazione!");
							} catch (MessagingException e) {
								e.printStackTrace();
							}
						}
					}
				} else if (action.equals("registration")) {
					Account account= new Account(email, password, "0", "ACCOUNT", parseDateFromString(data_di_nascita));
					System.out.println(account);
					ga.registerAccount(account);
					request.setAttribute("message", "La <b>registrazione</b> � stata effettuata con successo!");
					
				}
			}
		} catch (SQLException | ParseException e1) {
			e1.printStackTrace();
		}

		RequestDispatcher view = this.getServletContext().getRequestDispatcher("/account/registrazione.jsp");
		view.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	
	//metodi d'appoggio
	private Date parseDateFromString(String data_di_nascita) throws ParseException{
		SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd");
		java.util.Date date = f.parse(data_di_nascita);
		
		return new Date(date.getTime());
	}
}//fine classe










