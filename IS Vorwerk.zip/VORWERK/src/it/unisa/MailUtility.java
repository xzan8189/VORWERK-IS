package it.unisa;

import java.util.Date;
import java.util.Properties;

import javax.mail.*;
import javax.mail.internet.*;

import com.sun.mail.smtp.SMTPMessage;

public class MailUtility {

	public static void sendEmail(String dest, String oggetto, String testoEmail) throws MessagingException {
		Properties props = new Properties();
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.socketFactory.port", "465");
		props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.port", "805");

		Session sessionMail = Session.getDefaultInstance(props, new javax.mail.Authenticator() {
			@Override
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication("vincenzo8189@gmail.com", "criscuolo1");
			}
		});

		try {

			SMTPMessage message = new SMTPMessage(sessionMail);
			message.setFrom(new InternetAddress("no-replay@VORWERK.it"));
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(dest));
			message.setSubject("Conferma Registrazione - VORWERK");
			message.setContent(oggetto, "text/html");
			message.setText(testoEmail);
			message.setSentDate(new Date(System.currentTimeMillis()));
			message.setNotifyOptions(SMTPMessage.NOTIFY_SUCCESS);
			Transport.send(message);
			System.out.println("sent email");

		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}
	}

}
