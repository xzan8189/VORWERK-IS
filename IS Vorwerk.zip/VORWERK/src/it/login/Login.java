package it.login;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import it.unisa.control.AwardsController;
import it.unisa.model.Account;
import it.unisa.model.GestioneAccount;

/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	// variabili d'istanza
	private static final long serialVersionUID = 1L;
	static GestioneAccount model = new GestioneAccount();
	private Account a = new Account();

	public Login() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String email = request.getParameter("username");
		String password = request.getParameter("password");
		String action = request.getParameter("action");
		HttpSession oldSession = request.getSession(false);

		try {
			if (action.equalsIgnoreCase("login")) {
				Account aFound = model.findAccountById(email);
				if (aFound.getEmail() != null && !aFound.getEmail().equals("")) {
					Account a = model.login(email, password);
					if (a.getRole() != null && !a.getRole().equals("")) {
						if (a.getRole().equalsIgnoreCase("administrator")) {
							// l'autenticazione � corretta ed � un ADMIN

							// recupero la sessione
							if (oldSession != null)
								oldSession.invalidate(); // invalida la sessione se gi� esiste

							HttpSession currentSession = request.getSession(); // crea una nuova sessione
							currentSession.setAttribute("user", email);
							currentSession.setAttribute("password", password);
							currentSession.setAttribute("admin", true);
							currentSession.setMaxInactiveInterval(5 * 60); // 5 minuti di inattivit� massima

							response.sendRedirect(request.getContextPath() + "/home.jsp");
							return;

						} else if (a.getRole().equalsIgnoreCase("account")) {
							// l'autenticazione � corretta ed � un ACCOUNT

							// recupero la sessione
							if (oldSession != null)
								oldSession.invalidate(); // invalida la sessione se gi� esiste

							HttpSession currentSession = request.getSession(); // crea una nuova sessione
							currentSession.setAttribute("user", email);
							currentSession.setAttribute("password", password);
							currentSession.setAttribute("admin", false);
							currentSession.setAttribute("account", true);
							currentSession.setMaxInactiveInterval(5 * 60); // 5 minuti di inattivit� massima

							response.sendRedirect(
									response.encodeRedirectURL(request.getContextPath() + "/account/account.jsp"));
							return;

						}
					} else {
						System.out.println("login sbagliato");
						request.setAttribute("errorMessage",
								"La <b>Password</b> non corrispondone all'email indicata");
					}
				} else if (aFound.getEmail() != null && aFound.getEmail().equals("")) {
					request.setAttribute("errorMessage", "L'<b>Email</b> non � stata trovata nel database");
				}

			}
		} catch (SQLException | IOException e) {
			e.printStackTrace();
		}

		// se l'autenticazione fallisce
		RequestDispatcher view = this.getServletContext().getRequestDispatcher("/login.jsp");
		view.forward(request, response);

	}

}// fine servlet
