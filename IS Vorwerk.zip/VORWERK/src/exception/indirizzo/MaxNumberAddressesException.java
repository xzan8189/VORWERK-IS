package exception.indirizzo;

public class MaxNumberAddressesException extends Exception{

	public MaxNumberAddressesException() {
		super("Numero massimo di indirizzi raggiunto");
	}

	public MaxNumberAddressesException(String message) {
		super(message);
	}
	

}
