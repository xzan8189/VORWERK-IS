package exception.premio;

public class NameFormatPremioException extends Exception{

	public NameFormatPremioException() {
		super("Il formato del nome del premio non � corretto");
	}

	public NameFormatPremioException(String message) {
		super(message);
	}
	

}
