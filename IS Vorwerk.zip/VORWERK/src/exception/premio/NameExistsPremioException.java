package exception.premio;

public class NameExistsPremioException extends Exception{

	public NameExistsPremioException() {
		super("Il nome del premio gi� esiste nel database");
	}

	public NameExistsPremioException(String message) {
		super(message);
	}
	

}
