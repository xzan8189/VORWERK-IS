package exception.premio;

public class PointsValuePremioException extends Exception{

	public PointsValuePremioException() {
		super("Il valore dei punti del premio non � corretto");
	}

	public PointsValuePremioException(String message) {
		super(message);
	}
	

}
