package exception.premio;

public class QuantityAvailableValuePremioException extends Exception{

	public QuantityAvailableValuePremioException() {
		super("Il valore della quantit� disponibile del premio non � corretto");
	}

	public QuantityAvailableValuePremioException(String message) {
		super(message);
	}
	

}
