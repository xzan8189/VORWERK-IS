package exception.premio;

public class DescriptionFormatPremioException extends Exception{

	public DescriptionFormatPremioException() {
		super("Il formato della descrizione del premio non � corretta");
	}

	public DescriptionFormatPremioException(String message) {
		super(message);
	}
	

}
