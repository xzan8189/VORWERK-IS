package exception.account;

public class NoPointsException extends Exception{

	public NoPointsException() {
		super("Non ha abbastanza punti per richiedere il premio");
	}

	public NoPointsException(String message) {
		super(message);
	}
	

}
