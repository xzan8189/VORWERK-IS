package exception.account;

public class EmailFormatException extends Exception{

	public EmailFormatException() {
		super("Il formato dell'email non � corretto");
	}

	public EmailFormatException(String message) {
		super(message);
	}
	
	

}
