package exception.account;

public class EmailExistsException extends Exception{

	public EmailExistsException() {
		super("L'email gi� esiste nel database");
	}

	public EmailExistsException(String message) {
		super(message);
	}

}
