package exception.account;

public class IsNotOfAgeException extends Exception{

	public IsNotOfAgeException() {
		super("Non ha l'et� appropriata per registrarsi(deve essere maggiorenne)");
	}


	public IsNotOfAgeException(String message) {
		super(message);
	}
}
