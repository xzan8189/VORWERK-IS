package exception.account;

public class ResidenceNotInsertedException extends Exception{
	//Se non ha almeno un indirizzo/residenza allora semplicemente non proceder� con l'acquisto dei prodotti del carrello
	//e anche con la creazione dell'ordine dei premi

	public ResidenceNotInsertedException() {
		super();
	}

	public ResidenceNotInsertedException(String message) {
		super(message);
	}
	
	

}
