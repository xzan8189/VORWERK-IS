package exception.account;

public class EmailNotExistsException extends Exception{

	public EmailNotExistsException() {
		super("L'email non esiste nel database");
	}

	public EmailNotExistsException(String message) {
		super(message);
	}

}
