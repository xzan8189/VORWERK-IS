package exception.account;

public class PasswordFormatException extends Exception{

	public PasswordFormatException() {
		super("Il formato della password non � corretto");
	}

	public PasswordFormatException(String message) {
		super(message);
	}

}
