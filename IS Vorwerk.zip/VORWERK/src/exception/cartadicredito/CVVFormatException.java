package exception.cartadicredito;

public class CVVFormatException extends Exception{

	public CVVFormatException() {
		super("Il formato del CVV non � corretto");
	}

	public CVVFormatException(String message) {
		super(message);
	}

}
