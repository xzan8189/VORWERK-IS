package exception.cartadicredito;

public class CreditCardNotInsertedException extends Exception{
	//Se non ha la carta di credito allora semplicemente non proceder� con l'acquisto dei prodotti del carrello
	
	public CreditCardNotInsertedException() {
		super("Non esiste nessuna carta di credito");
	}

	public CreditCardNotInsertedException(String message) {
		super(message);
	}
	

}
