package exception.cartadicredito;

public class NumberCreditCardFormatException extends Exception{

	public NumberCreditCardFormatException() {
		super("Il numero della carta di credito non ha un formato corretto");
	}

	public NumberCreditCardFormatException(String message) {
		super(message);
	}

}
