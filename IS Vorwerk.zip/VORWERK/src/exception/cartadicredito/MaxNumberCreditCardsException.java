package exception.cartadicredito;

public class MaxNumberCreditCardsException extends Exception{

	public MaxNumberCreditCardsException() {
		super("Numero massimo di carte di credito raggiunto");
	}

	public MaxNumberCreditCardsException(String arg0) {
		super(arg0);
	}
	

}
