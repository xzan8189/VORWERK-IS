package exception.cartadicredito;

public class IntestatarioFormatException extends Exception{

	public IntestatarioFormatException() {
		super("Il formato dell'intestatario non � corretto");
	}

	public IntestatarioFormatException(String message) {
		super(message);
	}

}
