package exception.robot;

public class NameExistsRobotException extends Exception{

	public NameExistsRobotException() {
		super("Il nome del robot gi� esiste");
	}

	public NameExistsRobotException(String message) {
		super(message);
	}
	

}
