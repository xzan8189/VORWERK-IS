package exception.robot;

public class PriceValueRobotException extends Exception{

	public PriceValueRobotException() {
		super("Il prezzo del robot non � corretto");
	}

	public PriceValueRobotException(String message) {
		super(message);
	}
	

}
