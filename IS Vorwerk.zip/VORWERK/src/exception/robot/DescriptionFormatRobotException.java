package exception.robot;

public class DescriptionFormatRobotException extends Exception{

	public DescriptionFormatRobotException() {
		super("Il formato della descrizione non � corretto");
	}

	public DescriptionFormatRobotException(String message) {
		super(message);
	}
	

}
