package exception.robot;

public class QuantityAvailableValueRobotException extends Exception{

	public QuantityAvailableValueRobotException() {
		super("Il valore della quantit� disponibile del robot non � corretta");
	}

	public QuantityAvailableValueRobotException(String message) {
		super(message);
	}
	

}
