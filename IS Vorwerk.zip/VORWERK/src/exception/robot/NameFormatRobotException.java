package exception.robot;

public class NameFormatRobotException extends Exception{

	public NameFormatRobotException() {
		super("Il formato del nome del robot non � corretto");
	}

	public NameFormatRobotException(String message) {
		super(message);
	}
	

}
