/**
 * 
 */

function validateForm() {
  var email = document.forms["formRegistration"]["email"].value;
  var password = document.forms["formRegistration"]["password"].value;
  var data_di_nascita = document.forms["formRegistration"]["data_di_nascita"].value;
  if (email == "") {
    alert("Il campo dell'email deve essere compilato");
    return false;
  }
  
  if (password == "") {
	    alert("Il campo della password deve essere compilato");
	    return false;
	  }
  
  if (data_di_nascita == "") {
	    alert("Il campo della data di nascita deve essere compilato");
	    return false;
	  }
}