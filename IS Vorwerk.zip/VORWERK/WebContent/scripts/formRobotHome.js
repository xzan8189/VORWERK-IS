/**
 * 
 */

//Controllo del Form dell'inserimento di un robot
function controlRobotForm(form) {
	try {
		var flag=true;
		
		/*var name= $("#nameProduct").val();
		var price= $("#priceProduct").val();
		var description= $("#description").val();
		var quantity= $("#quantityProduct").val();
			
		$(".error").remove();

		//quantity
		if (quantity<=0 || quantity>999) {
			flag=false;
			$("#quantityProduct").removeClass("is-valid");
			$("#quantityProduct").addClass("is-invalid");
			$("#quantityProduct").focus();
			console.log("quantity false");
		} else {
			$("#quantityProduct").removeClass("is-invalid");
			$("#quantityProduct").addClass("is-valid");
			console.log("quantity true");
		}

		//description
		if (description.length<5 || description.length>255) {
			flag= false;
			$("#description").removeClass("is-valid");
			$("#description").addClass("is-invalid");
			$("#description").focus();
			console.log("description false");
		} else {
			$("#description").removeClass("is-invalid");
			$("#description").addClass("is-valid");
			console.log("description true");
		}

		//price
		if (price<=0 || price>999) {
			flag=false;
			$("#priceProduct").removeClass("is-valid");
			$("#priceProduct").addClass("is-invalid");
			$("#priceProduct").focus();
			console.log("price false");
		} else {
			$("#priceProduct").removeClass("is-invalid");
			$("#priceProduct").addClass("is-valid");
			console.log("price true");
		}
		
		//name
		if (name.length<5 || name.length>30) {
			flag=false;
			$("#nameProduct").removeClass("is-valid");
			$("#nameProduct").addClass("is-invalid");
			$("#nameProduct").focus();
			console.log("name false");
		} else {
			$("#nameProduct").removeClass("is-invalid");
			$("#nameProduct").addClass("is-valid");
			console.log("name true");
		}

		
		console.log("\n-------------");*/
		
		if (flag) {
			form.submit();
		}
	} catch (e) {
		console.log(e);
	}
}

//Controllo del Form dell'update di un robot
function controlUpdateRobotForm(form) {
	try {
		var flag=true;
		
		/*var name= $("#updateNameRobot").val();
		var price= $("#updatePriceRobot").val();
		var description= $("#updateDescriptionRobot").val();
		var quantity= $("#updateQuantityRobot").val();
			
		$(".error").remove();

		//quantity
		if (quantity<=0 || quantity>999) {
			flag=false;
			$("#updateQuantityRobot").removeClass("is-valid");
			$("#updateQuantityRobot").addClass("is-invalid");
			$("#updateQuantityRobot").focus();
			console.log("quantity false");
		} else {
			$("#updateQuantityRobot").removeClass("is-invalid");
			$("#updateQuantityRobot").addClass("is-valid");
			console.log("quantity true");
		}

		//description
		if (description.length<5 || description.length>255) {
			flag= false;
			$("#updateDescriptionRobot").removeClass("is-valid");
			$("#updateDescriptionRobot").addClass("is-invalid");
			$("#updateDescriptionRobot").focus();
			console.log("description false");
		} else {
			$("#updateDescriptionRobot").removeClass("is-invalid");
			$("#updateDescriptionRobot").addClass("is-valid");
			console.log("description true");
		}

		//price
		if (price<=0 || price>999) {
			flag=false;
			$("#updatePriceRobot").removeClass("is-valid");
			$("#updatePriceRobot").addClass("is-invalid");
			$("#updatePriceRobot").focus();
			console.log("price false");
		} else {
			$("#updatePriceRobot").removeClass("is-invalid");
			$("#updatePriceRobot").addClass("is-valid");
			console.log("price true");
		}
		
		//name
		if (name.length<5 || name.length>30) {
			flag=false;
			$("#updateNameRobot").removeClass("is-valid");
			$("#updateNameRobot").addClass("is-invalid");
			$("#updateNameRobot").focus();
			console.log("name false");
		} else {
			$("#updateNameRobot").removeClass("is-invalid");
			$("#updateNameRobot").addClass("is-valid");
			console.log("name true");
		}

		
		console.log("\n-------------");*/
		
		if (flag) {
			form.submit();
		}
	} catch (e) {
		console.log(e);
	}
}

//Tooltip validi ed invalidi del Form dell'inserimento e dell'update di un robot
function validInvalidTooltipRobot(updateOrInsert){
	
	
	/*if (updateOrInsert=='insertRobot') {
		var priceRobot= $("#priceProduct").val();
		var quantityRobot= $("#quantityProduct").val();
	
		//tooltip quantity
		if (quantityRobot<=0 || quantityRobot>999) {
			$('#errorQuantity').show();
		} else {
			$('#errorQuantity').hide();
		}
	
		//tooltip price
		if (priceRobot<=0 || priceRobot>999) {
			$('#errorPrice').show();
		} else {
			$('#errorPrice').hide();
		}
		
	}
	
	if (updateOrInsert=='updateRobot') {
		var updatePriceRobot= $("#updatePriceRobot").val();
		var updateQuantityRobot= $("#updateQuantityRobot").val();
	
		//tooltip quantity
		if (updateQuantityRobot<=0 || updateQuantityRobot>999) {
			$('#updateErrorQuantity').show();
		} else {
			$('#updateErrorQuantity').hide();
		}
	
		//tooltip price
		if (updatePriceRobot<=0 || updatePriceRobot>999) {
			$('#updateErrorPrice').show();
		} else {
			$('#updateErrorPrice').hide();
		}
		
	}*/
	
}