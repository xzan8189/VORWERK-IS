/**
 * 
 */

function validateForm() {
  var email = document.forms["formLogin"]["username"].value;
  var password = document.forms["formLogin"]["password"].value;
  if (email == "") {
    alert("Il campo dell'email deve essere compilato");
    return false;
  }
  
  if (password == "") {
	    alert("Il campo della password deve essere compilato");
	    return false;
	  }
}